import React, { Fragment } from 'react'
import Form from './Form'
import Leads from './Leads'
import { useSelector } from 'react-redux';


function Dashboard() {
  const { isAuthenticated, user } = useSelector((state) => (state.auth));
  return (
    <Fragment>

      {/* <Form />
      <Leads /> */}
      <h1>you are logged in as {user.username}</h1>

    </Fragment>
  )
}

export default Dashboard