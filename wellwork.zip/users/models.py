import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    profile_pic = models.ImageField(upload_to='profile_pics/', null=True, blank=True)
    team_leader = models.BooleanField(default=False)

    def __str__(self):
        return self.username

# class Team(models.Model):
#     name = models.CharField(max_length=255)
#     team_token = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
#     team_leader = models.ForeignKey(User, on_delete=models.CASCADE, related_name='led_teams')
#     members = models.ManyToManyField(User, related_name='teams', blank=True)

#     # def save(self, *args, **kwargs):
#     #     if not self.id:
#     #         self.team_leader.team_leader = True
#     #         self.team_leader.team_token = self.team_token
#     #         self.team_leader.save()
#     #     super().save(*args, **kwargs)


#     def __str__(self):
#         return self.name
