from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import UserViewSet
from .api import RegisterAPI,LoginAPI,UserAPI
from knox.views import LogoutView

router = DefaultRouter()
router.register(r'users', UserViewSet)
#router.register(r'teams', TeamViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('api/auth',include('knox.urls')),
    path('api/auth/register',RegisterAPI.as_view()),
    path('api/auth/login',LoginAPI.as_view()),
    path('api/auth/user',UserAPI.as_view()),
    path('api/auth/logout',LogoutView.as_view(),name='knox-logout')
]
